package com.alfresco;




import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.ObjectId;
import org.apache.chemistry.opencmis.client.api.Repository;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.client.api.SessionFactory;
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl;
import org.apache.chemistry.opencmis.commons.SessionParameter;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.enums.BindingType;

public class DocumentVersioning {
    private String serviceUrl = "http://localhost:8080/alfresco/api/-default-/public/cmis/versions/1.1/atom"; // Uncomment for Atom Pub binding
    private Session session = null;

    public static void main(String[] args) {
    	DocumentVersioning cce = new DocumentVersioning();
        cce.doExample();
    }

    public void doExample() {
        Document doc = (Document) getSession().getObjectByPath("/MyAlfrescoFolder1/NewTextFile.txt");
        String fileName = doc.getName();
        ObjectId pwcId = doc.checkOut(); // Checkout the document
        Document pwc = (Document) getSession().getObject(pwcId); // Get the working copy

        // Set up an updated content stream
        String docText = "This is a new major version.";
        byte[] content = docText.getBytes();
        InputStream stream = new ByteArrayInputStream(content);
        ContentStream contentStream = session.getObjectFactory().createContentStream(fileName, Long.valueOf(content.length), "text/plain", stream);

        // Check in the working copy as a major version with a comment
        ObjectId updatedId = pwc.checkIn(true, null, contentStream, "My new version comment");
        doc = (Document) getSession().getObject(updatedId);
        System.out.println("Doc is now version: " + doc.getProperty("cmis:versionLabel").getValueAsString());
        System.out.println("Doc is now version: " + doc.getProperty("cmis:name").getValue());
        
        List<Document> allVersion = doc.getAllVersions();
        for ( Document document : allVersion) 
        {
			System.out.println("Current Document version is " + document);
		}
        
    }

    public Session getSession() {

        if (session == null) {
            // default factory implementation
            SessionFactory factory = SessionFactoryImpl.newInstance();
            Map<String, String> parameter = new HashMap<String, String>();

            // user credentials
            parameter.put(SessionParameter.USER, "admin"); // <-- Replace
            parameter.put(SessionParameter.PASSWORD, "admin"); // <-- Replace

            // connection settings
            parameter.put(SessionParameter.ATOMPUB_URL, this.serviceUrl); // Uncomment for Atom Pub binding
            parameter.put(SessionParameter.BINDING_TYPE, BindingType.ATOMPUB.value()); // Uncomment for Atom Pub binding

            List<Repository> repositories = factory.getRepositories(parameter);

            this.session = repositories.get(0).createSession();
        }
        return this.session;
    }
}